package recordkeeping.system;

public class Student extends Person {

    private int studentID;
    private String classGroupCode;

    /**
     * @return the studentID
     */
    public int getStudentID() {
        return studentID;
    }

    /**
     * @param studentID the studentID to set
     */
    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    /**
     * @return the classGroupCode
     */
    public String getClassGroupCode() {
        return classGroupCode;
    }

    /**
     * @param classGroupCode the classGroupCode to set
     */
    public void setClassGroupCode(String classGroupCode) {
        this.classGroupCode = classGroupCode;
    }

}
