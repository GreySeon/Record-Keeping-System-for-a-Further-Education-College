/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recordkeeping.system;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Sergiy Sylenko
 */
public class Assessment {
    
    private String assessmentID;
    private String moduleCode;
    private int assignment1;
    private int assignment2;
    private int exam;
    private int overall;

    /**
     * @return the assessmentID
     */
    public String getAssessmentID() {
        return assessmentID;
    }

    /**
     * @param assessmentID the assessmentID to set
     */
    public void setAssessmentID(String assessmentID) {
        this.assessmentID = assessmentID;
    }

    /**
     * @return the moduleCode
     */
    public String getModuleCode() {
        return moduleCode;
    }

    /**
     * @param moduleCode the moduleCode to set
     */
    public void setModuleCode(String moduleCode) {
        this.moduleCode = moduleCode;
    }

    /**
     * @return the assignment1
     */
    public int getAssignment1() {
        return assignment1;
    }

    /**
     * @param assignment1 the assignment1 to set
     */
    public void setAssignment1(int assignment1) {
        this.assignment1 = assignment1;
    }

    /**
     * @return the assignment2
     */
    public int getAssignment2() {
        return assignment2;
    }

    /**
     * @param assignment2 the assignment2 to set
     */
    public void setAssignment2(int assignment2) {
        this.assignment2 = assignment2;
    }

    /**
     * @return the exam
     */
    public int getExam() {
        return exam;
    }

    /**
     * @param exam the exam to set
     */
    public void setExam(int exam) {
        this.exam = exam;
    }

    /**
     * @return the overall
     */
    public int getOverall() {
        return overall;
    }

    /**
     * @param overall the overall to set
     */
    public void setOverall(int overall) {
        this.overall = overall;
    }
    
    public void addColumn(javax.swing.JTable table) {
        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
        tableModel.addColumn("Assessment");
        tableModel.addColumn("1st Assignment");
        tableModel.addColumn("2nd Assignment");
        tableModel.addColumn("Exam");
        tableModel.addColumn("Overall");
    }
    
}
